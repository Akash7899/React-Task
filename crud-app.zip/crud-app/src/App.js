import React from "react";
import "../node_modules/bootstrap/dist/css/bootstrap.css";
import "../node_modules/bootstrap/dist/js/bootstrap.js";
import Table from "./Components/Table";
import "./App.css";

function App() {
  return (
    <div className="App">
      <Table />
    </div>
  );
}
export default App;
