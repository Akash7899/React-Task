import React from "react";
import Employee from "../Crud/Employee";

const Table = () => {
  return (
    <div className="container mt-5">
      <Employee />
    </div>
  );
};
export default Table;
